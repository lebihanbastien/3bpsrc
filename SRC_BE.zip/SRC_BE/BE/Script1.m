% First script of the BE.
% Computing a Halo orbit around EML2
%
% 2016
% 
% To complete: 
%      - diff_corr_3D_bb   (differential correction)
%      - orbit_postprocess (monodromy matrix)

%% Initialization of the workspace, constants and default parameters.
addpath(genpath('../'));
init;

%% To display (or not) the Earth
default.plot.firstPrimDisp = false;

%% Initialization of the environment
cr3bp = init_CR3BP('EARTH', 'MOON', default);

%% Initialization of the orbit
orbit = init_orbit(cr3bp, ...                     % Parent CR3BP
                   cr3bp.l2, ...                  % Parent libration point
                   cst.orbit.type.HALO, ...       % HALO orbit
                   cst.orbit.family.NORTHERN, ... % Northern class
                   12000, ...                     % Of vertical extension ~ 12000 km
                   cst);                          % Numerical constants

%% Computation of the orbit
orbit = orbit_computation(cr3bp, orbit, default, cst);