% Second script of the BE.
% Computing a Halo orbit around EML2 + its unstable directions + a branch
% of the unstable manifold.
%
% 2016
%
% To complete: 
%      - manifold_branch_computation_BE (what exactly?)
%

%% Call of the first script.
Script1

%% Stop plotting on figure 1
default.plot.XY = false;

%% Integration duration: arbitrarily fixed to 22 days
t = 22*cst.env.days*2*pi/cr3bp.T;

%% Initialization of the manifold
msi = init_manifold_branch(cst.manifold.UNSTABLE, cst.manifold.INTERIOR);

%% Computation of the manifold
% Departure position on the orbit in [0, 1]
theta = 0.0;
% Computation of the manifold branch
msi = manifold_branch_computation_BE(cr3bp, orbit, msi, theta, t, default, cst);