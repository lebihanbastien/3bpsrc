%% BE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Initialization: reboot, addpath, constants, default parameters. See init.m
init;

%% Inner changes from default parameters
default.plot.XZ = false;
default.plot.YZ = false;
default.plot.XY = false;
default.plot.SUBTD = true;

%% Structures init
% Environment
cr3bp = init_CR3BP('EARTH', 'MOON', default);
Lf = cr3bp.L;
Tf = 1e3*cr3bp.L*2*pi/cr3bp.T;

% Orbit
orbit = init_orbit(cr3bp, ...                     % Parent CR3BP
    cr3bp.l2, ...                  % Parent libration point
    cst.orbit.type.HALO, ...       % HALO orbit
    cst.orbit.family.NORTHERN, ... % Northern class
    12000, ...                     % Of vertical extension ~ 120000 km
    cst);                          % Numerical constants

%% Orbit computation
orbit = orbit_computation(cr3bp, orbit, default, cst);

%Interpolation matrix
% halo_init = halo_init_EML2;
% orbit = halo_orbit_interpolation(cr3bp, orbit, halo_init, default, cst);

% Initialize NRO
% orbit = init_nro(cr3bp, cr3bp.l2, cst.orbit.family.SOUTHERN, cst);
% % Interpolation and plot
% orbit = nro_interpolation(cr3bp, orbit, nro_init_EML2, default, cst, 'altitudeOfPerigee', 1000);

%% Integration duration: arbitrarily fixed to 30 days
t = 22*cst.env.days*2*pi/cr3bp.T;

%% At the Moon
moon.event = init_event(cst.manifold.event.type.FLIGHT_PATH_ANGLE,...      %the event is triggered when the flight path angle is...
    0.0,...                                            %equal to zero...
    cst.manifold.event.isterminal.YES,...              %the trajectory stops after a certain number of events
    cst.manifold.event.direction.ALL,...               %all direction are considered...
    cr3bp.m2.pos, cst);                                %the center for the computation of the angle is the Moon

%Associated ode options
moon.options = odeset('Events',@(t,y)odezero_flightpathangle(t,y,moon.event),...
    'Reltol', default.ode113.RelTol,...
    'Abstol', default.ode113.AbsTol);


%% First step: get the closest tangential approach of the Moon (Lunar Flyby)
default.plot.SUBTD = false;
% Vector of position on the orbit
thetav = 0:0.005:1;
thetan = size(thetav, 2);

% Outputs
output.lfb.yv     = zeros(thetan, 6);    % state at the best approach
output.lfb.tv     = zeros(thetan, 1);    % time at the best approach
output.halo.theta = zeros(thetan, 1);    % position on the halo orbit
output.halo.ind   = zeros(thetan, 1);    % indix of the best approach

% Loop on all the positions on the halo orbit
li = 1;
for theta = thetav
    
    % Initialize the manifold with a big max_events
    moon.event.max_events = 50;
    
    % Computation of the manifold branch + all the tangential points along
    % the trajectory
    default.plot.manifold_branch = false;
    msi = manifold_branch_computation(cr3bp, orbit, msi, theta, t, default, cst, moon.event);
    
    % Get the min distance to the surface of the Moon
    mindist2moonsurface = Inf;
    ind = 0;
    for i = 1: size(msi.yv, 1)
        dist2moonsurface = norm(msi.yv(i,1:3) - cr3bp.m2.pos) -  cr3bp.m2.Rm/cr3bp.L;
        if(dist2moonsurface < mindist2moonsurface)
            mindist2moonsurface = dist2moonsurface;
            ind = i;
        end
    end
    
    % Recompute the manifold, stopping at the right event
    default.plot.manifold_branch = true;
    moon.event.max_events = ind;
    msi  = init_manifold_branch_event(cst.manifold.UNSTABLE, cst.manifold.INTERIOR, moon.event);
    msi  = manifold_branch_computation(cr3bp, orbit, msi, theta, t, default, cst);
    
    % Save the output
    output.lfb.yv(li, :)  = msi.yv(ind,1:6);
    output.lfb.tv(li)     = msi.termination_time(ind);
    output.halo.theta(li) = theta;
    output.halo.ind(li)   = ind;
    li = li +1;
end


%% Postprocess

%--------------------------------------------------------------------------
% Latitude and Longitude on the Moon
%--------------------------------------------------------------------------
f1 = figure(6);
set(f1, 'Position', [83, 9, 1096, 946]);
subplot(2,2,1:2);
hold on
load moonalb
geoshow(moonalb, moonalbrefvec)
grid on
title('Selenographic frame');

% Vector of position (mean anomaly) on the LLO
Mv = 0:0.01:2*pi;
output.altitude    = zeros(thetan, 1);
output.latitude    = zeros(thetan, 1);
output.longitude   = zeros(thetan, 1);
output.llo.lat     = zeros(thetan, size(Mv, 2));
output.llo.long    = zeros(thetan, size(Mv, 2));

% Lunar radius
rm = cr3bp.m2.Rm/cr3bp.L;
% Lunar position
pm = cr3bp.m2.pos;
% Maximum altitude allowed at the Moon : 500 km.
maxalt = 500/cr3bp.L;

%--------------------------------------------------------------------------
% Loop on all the positions on the Halo orbit.
%--------------------------------------------------------------------------
for li = 1:thetan
    % Current state
    yv = output.lfb.yv(li, :)';
    tv = output.lfb.tv(li);
    
    % Current state wrt the Moon
    yvm = yv - [pm 0 0 0]';
    
    % Altitude wrt the mean Lunar surface
    output.altitude(li) = norm(yvm(1:3)) -  rm;
    
    % Distance from the center of the Moon
    output.rvm(li) = norm(yvm(1:3));
    
    % Latitude and longitude in selenographic coordinates
    ysg = synodical2selenographic(yv, cr3bp);
    output.latitude(li) = rad2deg(atan2(ysg(3), norm(ysg(1:2))));
    output.longitude(li)= rad2deg(atan2(ysg(2), ysg(1)));
    
    %State vector in selenocentric coordinates
    ysc = selenographic2selenocentric(ysg, tv);
    
    %----------------------------------------------------------------------
    %Osculating circular LLO
    %----------------------------------------------------------------------
    r = ysc(1:3); %position at the best approach in selenocentric frame
    v = ysc(4:6); %velocity at the best approach in selenocentric frame
    h =  cross(r, v); %Angular momentum vector
    
    % Keplerian elements
    Omega = atan2(h(1), -h(2));
    I = atan2(norm(h(1:2)), h(3));
    e = 0.0;
    a = norm(r);
    p = r2p(r', I, Omega);
    omega = atan2(p(2), p(1));
    n = sqrt(cr3bp.mu/a^3);
    
    % Compute the corresponding orbit
    yc = zeros(6, size(Mv, 2));
    ysyn = zeros(6, size(Mv, 2));
    for i = 1:size(Mv, 2)
        % Keplerian elements to selenocentric state
        yc(:,i)    = kep2cart(a, e, I, omega, Omega, Mv(i), cr3bp.mu);
        % Back to synodical coordinates
        ysg        = selenocentric2selenographic(yc(:,i), Mv(i)/n+tv);
        ysyn(:,i)  = selenographic2synodical(ysg, cr3bp);
        % Store in output
        output.llo.lat(li, i)  = rad2deg(atan2(ysg(3), norm(ysg(1:2))));
        output.llo.long(li, i) = rad2deg(atan2(ysg(2), ysg(1)));
    end
    
    % Maneuver to perform to insert into the LLO
    output.llo.dv(li) = norm(ysc(4:6)' - yc(4:6, 1));
    
    
    %----------------------------------------------------------------------
    %Plot solutions if they are good enough
    %----------------------------------------------------------------------
    if(output.altitude(li) > 0 && output.altitude(li) < maxalt)    
        
        % Recompute the manifold, stopping at the right event, with plot
        default.plot.manifold_branch = true;
        default.plot.SUBTD = true;
        moon.event.max_events = output.halo.ind(li);
        msi  = init_manifold_branch_event(cst.manifold.UNSTABLE, cst.manifold.INTERIOR, moon.event);
        msi  = manifold_branch_computation(cr3bp, orbit, msi, output.halo.theta(li), t, default, cst);
        
        %Equivalent of the trajectory in selenographic coordinates
        ntraj = size(msi.ytraj, 1);
        lat = zeros(1, ntraj);
        long = zeros(1, ntraj);
        for i = 1:ntraj
            yseltraj = synodical2selenographic(msi.ytraj(i,:)', cr3bp);
            lat(i)  = rad2deg(atan2(yseltraj(3), norm(yseltraj(1:2))));
            long(i) = rad2deg(atan2(yseltraj(2), yseltraj(1)));
        end
        
        %------------------------------------------------------------------
        % Update figure 5 & 6
        %------------------------------------------------------------------
        % Synodical frame
        figure(5);
        hold on
        quiver3(yv(1)*Lf, yv(2)*Lf, yv(3)*Lf, yv(4)*Tf, yv(5)*Tf, yv(6)*Tf, 'Color', 'b');
        plot3(ysyn(1,:)*Lf, ysyn(2,:)*Lf, ysyn(3,:)*Lf, 'b');
        
        % Selenographic frame
        figure(6);
        subplot(2,2,1:2);
        hold on
        geoshow(lat, long, 'DisplayType', 'Line', 'Color', 'r');
        geoshow(output.latitude(li), output.longitude(li), 'DisplayType', 'Point', 'Marker', 'o', 'MarkerSize', 7, 'MarkerEdgeColor', 'w', 'MarkerFaceColor', 'w');
        geoshow(output.llo.lat(li,:), output.llo.long(li,:), 'DisplayType', 'Line', 'Color', 'w');
        xlabel('Longitude (°)');
        ylabel('Latitude (°)');

        % Inclination vs Altitude of the LLO
        subplot(2,2,3);
        hold on;
        xlabel('Inclination (°)');
        ylabel('Altitude (km)');
        plot(rad2deg(I), output.altitude(li)*Lf, 'o', 'Color', 'k', 'MarkerFaceColor', 'k', 'MarkerSize', 7);
        grid on;
        title('Parameters of the Low Lunar Orbit (LLO)');
        
        % Inclination vs DV of the LLO
        subplot(2,2,4);
        hold on;
        plot(rad2deg(I), output.llo.dv(li)*Lf*2*pi/(cr3bp.T), 'o', 'Color', 'k', 'MarkerFaceColor', 'k', 'MarkerSize', 7);
        xlabel('Inclination (°)');
        ylabel('DV (km/s)');
        grid on;
        title('Lunar insertion maneuver cost');
    end
    
end

return;

%% Get the Min distance to the surface of the Moon
supermindist2moonsurface = Inf;
thetaargmin = 0;
indargmin = 0;

for theta = 0:0.1:1
    
    % Manifold computation
    moon.event.max_events = 15;
    msi  = init_manifold_branch_event(cst.manifold.UNSTABLE, cst.manifold.INTERIOR, moon.event);
    
    % Computation and plot
    default.plot.manifold_branch = false;
    msi = manifold_branch_computation(cr3bp, orbit, msi, theta, t, default, cst);
    
    % Get Min Distance to Moon and right index of event
    mindist2moonsurface = Inf;
    ind = 0;
    for i = 1: size(msi.yv, 1)
        dist2moonsurface = norm(msi.yv(i,1:3) - cr3bp.m2.pos) -  cr3bp.m2.Rm/cr3bp.L;
        if(dist2moonsurface < mindist2moonsurface)
            mindist2moonsurface = dist2moonsurface;
            ind = i;
        end
    end
    
    if(mindist2moonsurface < supermindist2moonsurface && mindist2moonsurface > 0)
        supermindist2moonsurface = mindist2moonsurface;
        thetaargmin = theta;
        indargmin   = ind;
    end
end

default.plot.manifold_branch = true;
theta = thetaargmin;
moon.event.max_events = indargmin;
msi  = init_manifold_branch_event(cst.manifold.UNSTABLE, cst.manifold.INTERIOR, moon.event);
msi = manifold_branch_computation(cr3bp, orbit, msi, theta, t, default, cst);
supermindist2moonsurface*cr3bp.L;


return;
%% DiffCorr Init
tspan = [0 5];
Lf = cr3bp.L;
yv = msi.yv0;
yv = matrixToVector(yv, cst.orbit.STM0, 6, 6, 6);

iter2 = 0;


while(dist2moonsurface > 200/Lf)
    
    
    iterMax = 10;
    user.hLMOa = dist2moonsurface - 5/Lf;
    user.showSteps = false;
    
    %% Completing the plot (Include the LEO)
    if(default.plot.XY && mod(iter2, 10) == 0)
        Rm2 = cr3bp.m2.Rm/cr3bp.L;
        VTheta = 0:0.01:2*pi;
        X_LEO = 1-cr3bp.mu + (Rm2 + user.hLMOa) *cos(VTheta);
        Y_LEO =      0    +  (Rm2 + user.hLMOa) *sin(VTheta);
        figure(1)
        hold on;
        plot(X_LEO*cr3bp.L, Y_LEO*cr3bp.L,':k');
    end
    
    %% Diff Corr
    iter = 0;
    %Maximum iterations in the Differential Correction scheme
    isSolution = false;
    while(iter < iterMax)
        
        %------------------------------------------------------------------
        %Integration until a null terrestrial flight path angle is
        %reached
        %------------------------------------------------------------------
        %[~, yarc, tearc, yearc, ~] = ode113(@(t,y)cr3bp_derivatives_42(t,y,cr3bp.mu),tspan,yv, moon.options);
        if(mod(iter2, 50) == 0)
            [tearc, yearc2, ~, yarc] = ode78_cr3bp_event(tspan, yv, cr3bp.mu, moon.event);
        else
            [tearc, yearc2] = ode78_cr3bp_event(tspan, yv, cr3bp.mu, moon.event);
        end
        
        %--------------------------------------------------------------
        %Plot succesive steps, if desired
        %--------------------------------------------------------------
        if(user.showSteps)
            figure(1)
            hold on
            plot(yarc(:,1)*cr3bp.L ,yarc(:,2)*cr3bp.L , 'b');
            plot(yearc2(end,1)*cr3bp.L ,yearc2(end,2)*cr3bp.L , '*b');
        end
        
        %------------------------------------------------------------------
        % If the event has occured, the first order correction to apply
        % to the initial state is computed.
        %------------------------------------------------------------------
        if(~isempty(yearc2)) %if the event has occured
            yearc = yearc2(end,:);
            %--------------------------------------------------------------
            % Update the elements at the maneuver point
            %--------------------------------------------------------------
            %Final position
            ef = yearc(1:3)';
            %Final position wrt Moon
            ertf = ef - cr3bp.m2.pos';
            %Final velocity wrt Moon
            vrtf = yearc(4:6)';
            %Final STM
            STMf = vectorToMatrix(yearc, 6, 6, 6);
            
            %--------------------------------------------------------------
            % The error E1 that we seek to nullify: it is the error
            % with respect to the desired LEO altitude.
            %--------------------------------------------------------------
            E1 = norm(ertf) - cr3bp.m2.Rm/cr3bp.L - user.hLMOa;
            
            %--------------------------------------------------------------
            % Check if the error is small enough to stop the procedure
            %--------------------------------------------------------------
            if(abs(E1) < 1e-6)
                %disp('lfb. A LEO solution has been found.');
                isSolution = true;
                break;
            end
            
            %--------------------------------------------------------------
            % Correction matrix:
            %
            %         | ertf(1)/|ertf|  ertf(2)/|ertf|   ertf(3)/|ertf|  |
            % Mcorr = |  vrtf(1)        vrtf(2)           vrtf(3)        |
            %         |  ertf(1)        ertf(2)           ertf(3)        |
            %
            % where ertf is the position with respect to the Earth at the
            % maneuver point, and vrtf is the corresponding velocity.
            %--------------------------------------------------------------
            Mcorr = zeros(2,6);
            Mcorr(1,1:3) = + ertf(1:3) / norm(ertf);
            Mcorr(2,1:3) = - vrtf(1:3);
            Mcorr(2,4:6) = - ertf(1:3);
            
            %--------------------------------------------------------------
            %  Concatenated matrix:
            %
            %  Merror = |Phi artf|
            %
            %  where Phi is the State Transistion Matrix (STM) at the
            %  maneuver point, and artf the acceleration at the same point.
            %--------------------------------------------------------------
            Merror = zeros(6,4);
            for i = 1 : 6
                for j = 1 : 3
                    Merror(i,j) = STMf(i,j+3);
                end
            end
            
            %Derivation of yearc
            efd = cr3bp_derivatives_6(0, yearc, cr3bp.mu);
            
            for i = 1 : 6
                Merror(i,4) = efd(i);
            end
            
            %--------------------------------------------------------------
            % Error matrix is the product Mcorr*Merror
            %--------------------------------------------------------------
            Merror_c = Mcorr * Merror;
            
            %--------------------------------------------------------------
            % Error vector
            %--------------------------------------------------------------
            vec_error = - [E1 ; 0];
            
            %--------------------------------------------------------------
            % Correction to be made on the initial conditions: the minimum
            % norm solution is selected (see  equation 4.5 in Gordon).
            %--------------------------------------------------------------
            delta_correction = Merror_c' * ( (Merror_c * Merror_c') \ vec_error);
            
            
            %--------------------------------------------------------------
            % Updating the initial conditions
            %--------------------------------------------------------------
            for i = 1 : 3
                yv(i+3) =  yv(i+3) + delta_correction(i);
            end
            
            %--------------------------------------------------------------
            %Update the iterator
            %--------------------------------------------------------------
            iter = iter + 1;
            
            
        else  %no event, we return
            disp('lfb. Tangency at the Earth is not obtained. return.');
            isSolution = false;
            return;
        end
        
        
    end
    
    if(default.plot.XY && isSolution && mod(iter2, 50) == 0)
        figure(1)
        hold on
        plot(yarc(:,1)*cr3bp.L ,yarc(:,2)*cr3bp.L , 'm', 'LineWidth', 1.5);
    end
    
    dist2moonsurface = norm(yearc(1:3) - cr3bp.m2.pos) -  cr3bp.m2.Rm/cr3bp.L;
    dist2moonsurface*Lf
    iter2 = iter2+1;
end

%% Selenocentric framework

% figure(5);
% hold on
% Rm2 = cr3bp.m2.Req/cr3bp.L;
% [X_M3D, Y_M3D, Z_M3D] = sphere;
% X_M3D = 0  + Rm2*X_M3D;
% Y_M3D = 0  + Rm2*Y_M3D;
% Z_M3D = 0  + Rm2*Z_M3D;
% surf(X_M3D*Lf, Y_M3D*Lf, Z_M3D*Lf, 'FaceColor', [23 153 179]./255, 'FaceLighting', 'none', 'EdgeColor', [9 63 87]./255);
% axis equal
% grid on
% xlabel('X (x km)')
% ylabel('Y (x km)')
% zlabel('Z (x km)')
% title ('Selenocentric frame');
% arrow3([0 0 0], [0.02*Lf 0 0], 'r', 2, 10,0.5);
% arrow3([0 0 0], [0 0.02*Lf 0], 'g', 2, 10,0.5);
% arrow3([0 0 0], [0 0 0.02*Lf], 'b', 2, 10,0.5);

%     figure(5);
%     hold on
%     plot3(ysc(1)*Lf, ysc(2)*Lf, ysc(3)*Lf, 'o', 'Color', 'k', 'MarkerFaceColor', 'k');
%     plot3(yc(1,:)*Lf, yc(2,:)*Lf, yc(3,:)*Lf, 'b');
%     quiver3(ysc(1)*Lf, ysc(2)*Lf, ysc(3)*Lf, ysc(4)*Tf, ysc(5)*Tf, ysc(6)*Tf, 'Color', 'k', 'LineWidth', 2);
%     quiver3(yc(1,1)*Lf, yc(2,1)*Lf, yc(3,1)*Lf, yc(4,1)*Tf, yc(5,1)*Tf, yc(6,1)*Tf, 'Color', 'r', 'LineWidth', 2);
