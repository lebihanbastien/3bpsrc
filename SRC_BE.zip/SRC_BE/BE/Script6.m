% Sixth script of the BE.
% Computing a Halo orbit around EML2 + its unstable directions + a branch
% of the unstable manifold, stopping at the closest approach of the lunar
% surface + targeting a specific altitude with a DIFFCORR
%
% PROBLEM: very sensitive to initial conditions! Probably not worth it.
% OR continuation procedure, but even more complicated!
%
% 2016

%% Call of the first script: building the orbit
Script1

%% Stop plotting on figure 1
default.plot.XY = false;

%% Integration duration of the manifold arbitrarily fixed to 5 days
t = 22*cst.env.days*2*pi/cr3bp.T;

%% Initialization & computation of the manifold
msi = init_manifold_branch(cst.manifold.UNSTABLE, cst.manifold.INTERIOR);
default.plot.manifold_branch = false;
% Departure position on the orbit in [0, 1]
theta = 0.23;
% Computation of the manifold branch.
msi = manifold_branch_computation_moon(cr3bp, orbit, msi, theta, t, default, cst);

%% Moon event
moon.event = init_event(cst.manifold.event.type.FLIGHT_PATH_ANGLE,...      %the event is triggered when the flight path angle is...
    0.0,...                                                                %equal to zero...
    cst.manifold.event.isterminal.YES,...                                  %the trajectory stops after a certain number of events
    cst.manifold.event.direction.ALL,...                                   %all direction are considered...
    cr3bp.m2.pos, cst);                                                    %the center for the computation of the fpa angle is the Moon

% Initialize the manifold with a big max_events
moon.event.max_events = msi.ind;

%% Targeting a 50 km LLO altitude
user.hLMOa = 50/cr3bp.L;;

%% DiffCorr Init

%--------------------------------------------------------------------------
% Useful parameters
%--------------------------------------------------------------------------
% Time span
tspan = [0 t];
% Earth-Moon distance
Lf = cr3bp.L;
% The velocity factor
Tf = cr3bp.L*2*pi/cr3bp.T;
% Iterations max
iterMax = 10;
% Display the iterations or not
user.showSteps = true;

%--------------------------------------------------------------------------
% Initial state
%--------------------------------------------------------------------------
yv = msi.yv0;
yv = matrixToVector(yv, cst.orbit.STM0, 6, 6, 6);

%% Differential Correction
iter = 0;
%Maximum iterations in the Differential Correction scheme
isSolution = false;
while(iter < iterMax)
    %------------------------------------------------------------------
    %Integration until a null terrestrial flight path angle is
    %reached
    %------------------------------------------------------------------
    [tearc, yearc2, ~, yarc] = ode78_cr3bp_event(tspan, yv, cr3bp.mu, moon.event);

    
    %--------------------------------------------------------------
    %Plot succesive steps, if desired
    %--------------------------------------------------------------
    if(user.showSteps)
        figure(1)
        hold on
        plot(yarc(:,1)*cr3bp.L ,yarc(:,2)*cr3bp.L , 'b');
        plot(yearc2(end,1)*cr3bp.L ,yearc2(end,2)*cr3bp.L , '*b');
    end
    
    %------------------------------------------------------------------
    % If the event has occured, the first order correction to apply
    % to the initial state is computed.
    %------------------------------------------------------------------
    if(~isempty(yearc2)) %if the event has occured
        yearc = yearc2(end,:);
        %--------------------------------------------------------------
        % Update the elements at the maneuver point
        %--------------------------------------------------------------
        %Final position
        ef = yearc(1:3)';
        %Final position wrt Moon
        ertf = ef - cr3bp.m2.pos';
        %Final velocity wrt Moon
        vrtf = yearc(4:6)';
        %Final STM
        STMf = vectorToMatrix(yearc, 6, 6, 6);
        
        %--------------------------------------------------------------
        % The error E1 that we seek to nullify: it is the error
        % with respect to the desired LEO altitude.
        %--------------------------------------------------------------
        E1 = norm(ertf) - cr3bp.m2.Rm/cr3bp.L - user.hLMOa;
        
        %--------------------------------------------------------------
        % Check if the error is small enough to stop the procedure
        %--------------------------------------------------------------
        if(abs(E1) < 1e-12)
            disp('A solution has been found.');
            isSolution = true;
            break;
        end
        
        %--------------------------------------------------------------
        % Correction matrix:
        %
        %         | ertf(1)/|ertf|  ertf(2)/|ertf|   ertf(3)/|ertf|  |
        % Mcorr = |  vrtf(1)        vrtf(2)           vrtf(3)        |
        %         |  ertf(1)        ertf(2)           ertf(3)        |
        %
        % where ertf is the position with respect to the Earth at the
        % maneuver point, and vrtf is the corresponding velocity.
        %--------------------------------------------------------------
        Mcorr = zeros(2,6);
        Mcorr(1,1:3) = + ertf(1:3) / norm(ertf);
        Mcorr(2,1:3) = - vrtf(1:3);
        Mcorr(2,4:6) = - ertf(1:3);
        
        %--------------------------------------------------------------
        %  Concatenated matrix:
        %
        %  Merror = |Phi artf|
        %
        %  where Phi is the State Transistion Matrix (STM) at the
        %  maneuver point, and artf the acceleration at the same point.
        %--------------------------------------------------------------
        Merror = zeros(6,4);
        for i = 1 : 6
            for j = 1 : 3
                Merror(i,j) = STMf(i,j+3);
            end
        end
        
        %Derivation of yearc
        efd = cr3bp_derivatives_6(0, yearc, cr3bp.mu);
        
        for i = 1 : 6
            Merror(i,4) = efd(i);
        end
        
        %--------------------------------------------------------------
        % Error matrix is the product Mcorr*Merror
        %--------------------------------------------------------------
        Merror_c = Mcorr * Merror;
        
        %--------------------------------------------------------------
        % Error vector
        %--------------------------------------------------------------
        vec_error = - [E1 ; 0];
        
        %--------------------------------------------------------------
        % Correction to be made on the initial conditions: the minimum
        % norm solution is selected (see  equation 4.5 in Gordon).
        %--------------------------------------------------------------
        delta_correction = Merror_c' * ( (Merror_c * Merror_c') \ vec_error);
        
        
        %--------------------------------------------------------------
        % Updating the initial conditions
        %--------------------------------------------------------------
        for i = 1 : 3
            yv(i+3) =  yv(i+3) + delta_correction(i);
        end
        
        %--------------------------------------------------------------
        %Update the iterator
        %--------------------------------------------------------------
        iter = iter + 1;
           
    else  %no event, we return
        disp('lfb. Tangency at the Earth is not obtained. return.');
        isSolution = false;
        return;
    end
    
    
end

if(isSolution)
    figure(4)
    hold on
    plot3(yarc(:,1)*cr3bp.L ,yarc(:,2)*cr3bp.L, yarc(:,3)*cr3bp.L , 'm', 'LineWidth', 1.5);
end

%% Postprocess

%--------------------------------------------------------------------------
% Maneuver on the Halo orbit
%--------------------------------------------------------------------------
output.dv1 = norm(msi.yv0(4:6) - yv(4:6));

%--------------------------------------------------------------------------
%Final state and time
%--------------------------------------------------------------------------
% State in selenographic coordinates
ysg = synodical2selenographic(yearc(1:6)', cr3bp);
% State in selenocentric coordinates
ysc = selenographic2selenocentric(ysg, tearc(end));

%--------------------------------------------------------------------------
%Osculating circular LLO
%--------------------------------------------------------------------------
% Keplerian elements
[a, e, I, omega, Omega] = cart2circkep(ysc);

% Initial state on the LLO
yc = circkep2cart(a, e, I, omega, Omega, 0.0, cr3bp.mu);

%Maneuver to perform to insert into the first orbit
output.dv2 = norm(ysc(4:6)' - yc(4:6));

%--------------------------------------------------------------------------
%Display
%--------------------------------------------------------------------------
figure(4);
hold on
title(['LLO altitude reached: ', 'DV1 = ', num2str(output.dv1, '%2.2e'),...
      ' km/s, DV2 = ', num2str(output.dv2, '%2.2f'), ' km/s']);
% fprintf('DV1 : %5.5f km/s\n', output.dv1*Tf);
% fprintf('DV2 : %5.5f km/s\n', output.dv2*Tf);