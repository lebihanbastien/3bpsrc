% Fifth script of the BE.
% Computing a Halo orbit around EML2 + its unstable directions + the
% complete unstable manifold, stopping at the closest approach of the lunar
% surface. Then, a study of the directly reachable LLO is performed.
%
% Frozen orbits of the Moon: i = 27°, 50°, 76°, and 86°.
% To complete: 
%      - Find that the Az that allows to get the first frozen orbits of the
%      Moon is around 12000 km (i.e/ see that i increases with Az, more or
%      less).
%      - We have to set a max Az (20000) OR use an interpolation procedure
%
% 2016

%% Call of the first script: building the orbit
Script1

%% Stop plotting on figure 1
default.plot.XY = false;

%% Initialization of the manifold
msi = init_manifold_branch(cst.manifold.UNSTABLE, cst.manifold.INTERIOR);
default.plot.manifold_branch = false;

%% Reachability of the Moon
% Vector of positions on the halo orbit
thetav = 0:0.01:1;
% Moon reachability
[output] = moonreachability(cr3bp, orbit, msi, thetav, default, cst);
