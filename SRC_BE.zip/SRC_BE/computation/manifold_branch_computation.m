function manifold_branch = manifold_branch_computation(cr3bp, orbit, manifold_branch, pos, t, params, cst, varargin)
% MANIFOLD_BRANCH_COMPUTATION computes a manifold leg associated to a given
% orbit in the CRTBP.
%
% MANIFOLD_BRANCH_COMPUTATION(CR3BP, ORBIT, MANIFOLD_BRANCH, POS, T,
% PARAMS, CST) computes a manifold leg in the system CR3BP associated to
% the orbit ORBIT, from information contained in the structure
% MANIFOLD_BRANCH. The starting position on the orbit is given by the
% variable POS (POS in [0 1] covers the entire orbit, but any value POS>0
% is accepted). The manifold leg is then integrated up to the time T
% (resp. -T) if is unstable (resp. stable). Moreover, an event structure
% must be provided in the MANIFOLD_BRANCH structure (see
% INIT_MANIFOLD_BRANCH). This structure defines the condition to terminate
% the integration of the manifold leg before |t| = T is reached (e.g.
% intersection with a given plane, at a given angle, etc).
%
% See Koon et al. 2006, chapter 7, for details <a href="matlab:
% web('http://www.cds.caltech.edu/~marsden/volume/missiondesign/KoLoMaRo_DMissionBook_2011-04-25.pdf','-browser')">(link)</a>.
%
% MANIFOLD_BRANCH_COMPUTATION(CR3BP, ORBIT, MANIFOLD_BRANCH, POS, T,
% PARAMS, CST, EVENT) does the same thing, but the termination event is
% user-provided in the form of an event structure EVENT.
%
%
% See also INIT_MANIFOLD_BRANCH
%
% BLB 2016

%--------------------------------------------------------------------------
%Switch on the number of inputs
%--------------------------------------------------------------------------
switch(nargin)
    case 7
        %------------------------------------------------------------------
        %default number of inputs: the EVENT is defined from the
        %information contained in MANIFOLD_BRANCH
        %------------------------------------------------------------------
        %Check that an EVENT structure was provided by the user inside the
        %MANIFOLD_BRANCH
        if(~isfield(manifold_branch, 'event'))
            error('No EVENT structure was provided inside the MANIFOLD_BRANCH.')
        end
        
    case 8
        %----------------------------------------------------------
        % A user-defined user structure has been provided
        % After this step, we are in a situation exactly equivalent
        % of nargin = 7. In particular, the event structure
        % MANIFOLD_BRANCH.EVENT is overwritten.
        %----------------------------------------------------------
        manifold_branch.event = varargin{1};
    otherwise
        error('Wrong number of inputs.');
end


%--------------------------------------------------------------------------
% Integration on the orbit until the position POS is reached.
% POS should satisfy POS >= 0.
%--------------------------------------------------------------------------
if(pos > 0)
    [~, ytraj] = ode78_cr3bp([0 orbit.T*pos], orbit.y0, cr3bp.mu);
else
    ytraj = orbit.y0';
end

%--------------------------------------------------------------------------
% Current STM at POS
%--------------------------------------------------------------------------
STM = eye(6);
for i = 1 : 6
    for j = 1 : 6
        m = 6*(i-1) + j;
        STM(i,j) = ytraj(m+6);
    end
end

%--------------------------------------------------------------------------
% New vectors and initial state at POS
%--------------------------------------------------------------------------
if(manifold_branch.stability == cst.manifold.STABLE)
    vecp = STM*orbit.stable_direction;%New vector
    vecp_norm = vecp/norm(vecp);
else
    vecp = STM*orbit.unstable_direction;%New vector
    vecp_norm = vecp/norm(vecp);
end

%Initial state
xs01 = (1:6)';
for i = 1 : 6
    xs01(i) = ytraj(end,i) + vecp_norm(1)*manifold_branch.way*cr3bp.d_man*vecp_norm(i);
end

%--------------------------------------------------------------------------
% Save initial point in manifold
%--------------------------------------------------------------------------
manifold_branch.yv0 = xs01;

%--------------------------------------------------------------------------
%Integration direction
%--------------------------------------------------------------------------
% Backwards or forward integration
if(manifold_branch.stability == cst.manifold.STABLE)
    tspan = [0 -t];
else
    tspan = [0 t];
end

%--------------------------------------------------------------------------
% Event conditions
%--------------------------------------------------------------------------
switch(manifold_branch.event.type)
    case cst.manifold.event.type.FREE
        [te, yve, ~, ytraj] = ode78_cr3bp(tspan, xs01, cr3bp.mu);
    otherwise
        [te, yve, ~, ytraj] = ode78_cr3bp_event(tspan, xs01, cr3bp.mu, manifold_branch.event);
end

%--------------------------------------------------------------------------
% Output
%--------------------------------------------------------------------------
manifold_branch.te    = te;      %time of the events
manifold_branch.yve   = yve;     %state at the events
manifold_branch.ytraj = ytraj;   %entire trajectory

%--------------------------------------------------------------------------
% Plotting (potentially)
%--------------------------------------------------------------------------
if(params.plot.manifold_branch)
    manifold_plot(ytraj, orbit, manifold_branch, params, cst);
end


end