function orbit = orbit_refinement(cr3bp, orbit, params, yvg, cst, varargin)
% ORBIT_REFINEMENT computation of halo
% symmetric periodic orbits in the CRTBP, from an initial guess.
%
% ORBIT = ORBIT_REFINEMENT(CR3BP, ORBIT, PARAMS, YVG, CST) computes an 
% orbit in the system CR3BP, with the desired characteristics
% listed in the structure ORBIT (size or energy, lagrange point), and from
% an first guess of initial condition YVG.
% A differential correction process is applied to get a real periodic 
% orbit.
% Finally, a post process routine is applied in order to compute various
% characteristics of the orbit, listed below. Depending on the user-defined
% parameter structure PARAMS, the result can be plotted at the end of the
% routine.
%
% See Koon et al. 2006, chapter 6, for details <a href="matlab: 
% web('http://www.cds.caltech.edu/~marsden/volume/missiondesign/KoLoMaRo_DMissionBook_2011-04-25.pdf','-browser')">(link)</a>.
%
%
% At the end of this routine, the following parameters are updated in the
% orbit structure:
%
%   - ORBIT.y0:  the initial conditions.
%   - ORBIT.T12: the half period.
%   - ORBIT.T:   the full period.
%   - Either the couple (Az, Azdim) - vertical extension for halo and
%   vertical orbits, or the couple (Ax, Axdim), maximum planar extension
%   for planar lyapunov orbits.
%   - ORBIT.C: the jacobian constant
%   - ORBIT.E: the energy
%   - ORBIT.yv: the state along the orbit on a given grid over the interval
%   [0, orbit.T].
%   - ORBIT.monodromy: the monodromy matrix.
%   - ORBIT.eigenvalues: the eigenvalues of the monodromy matrix in vector
%   form.
%   - ORBIT.stable_direction: the stable eigenvector of the monodromy
%   matrix.
%   - ORBIT.unstable_direction: the unstable eigenvector of the monodromy
%   matrix.
%
% BLB 2016

%--------------------------------------------------------------------------
% Initialisation of the initial conditions:
% yv0 = [yvg ; State Transition Matrix]
%--------------------------------------------------------------------------
% Integration vector
yv0 = (1:42)';
% 6-dim state from a first approximation
yv0(1:6) = yvg(1:6);
% STM concatenation after the 6-dim state
yv0 = matrixToVector(yv0, cst.orbit.STM0, 6, 6, 6);

%--------------------------------------------------------------------------
% Differential correction procedure (DCP). At the end of this procedure,
% the following elements (at least) are updated in the orbit structure:
%   - orbit.y0:         initial conditions.
%   - orbit.T12:        half period.
%   - orbit.T:          period.
%--------------------------------------------------------------------------
orbit = diff_corr_3D_bb(yv0, cr3bp , orbit, params, cst);
  
%--------------------------------------------------------------------------
% Status
%--------------------------------------------------------------------------
orbit.status = cst.orbit.REAL;

%--------------------------------------------------------------------------
% Postprocess. After this step, the following elements are updated in the
% orbit structure:
%
%   - Either the couple (Az, Azdim) - vertical extension for halo and
%   vertical orbits, or the couple (Ax, Axdim), maximum planar extension
%   for planar lyapunov orbits.
%   - orbit.C: the jacobian constant
%   - orbit.E: the energy
%   - orbit.yv: the state along the orbit on a given grid over the interval
%   [0, orbit.T].
%   - orbit.monodromy: the monodromy matrix.
%   - orbit.eigenvalues: the eigenvalues of the monodromy matrix in vector
%   form.
%   - orbit.stable_direction: the stable eigenvector of the monodromy
%   matrix.
%   - orbit.unstable_direction: the unstable eigenvector of the monodromy
%   matrix.
%--------------------------------------------------------------------------
orbit = orbit_postprocess(cr3bp, orbit);

%--------------------------------------------------------------------------
% Plotting (potentially)
%--------------------------------------------------------------------------
if(params.plot.orbit) %plotting
    orbit_plot(orbit, params);
end

end