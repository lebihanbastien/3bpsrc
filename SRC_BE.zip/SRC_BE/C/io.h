#ifndef IO_H_INCLUDED
#define IO_H_INCLUDED

int reads(char *input, int length);

#endif // IO_H_INCLUDED
