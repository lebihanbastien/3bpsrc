#include "Oftsh.h"

Oftsh::Oftsh()
{
    //ctor
}

Oftsh::~Oftsh()
{
    //dtor
}
